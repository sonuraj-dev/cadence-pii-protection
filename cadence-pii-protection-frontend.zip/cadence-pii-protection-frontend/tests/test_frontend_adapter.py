from __future__ import annotations

from pathlib import Path

import pytest
from docx import Document

import frontend_adapter as adapter


def make_docx(text: str) -> bytes:
    from io import BytesIO

    document = Document()
    document.add_paragraph(text)
    buffer = BytesIO()
    document.save(buffer)
    return buffer.getvalue()


def test_successful_supported_document_uses_backend_and_passes_strict_gate():
    payload = make_docx("Contact us at analyst@example.com, employee EMP-12345.")
    result = adapter.process_uploaded_document("sample.docx", payload)

    assert result["filename"] == "sample.docx"
    assert result["extraction"]["complete"] is True
    assert result["gate_status"] == "validated"
    assert result["safe_to_process"] is True
    assert result["validation"]["passed"] is True
    assert result["redaction_count"] >= 1
    sanitized = "\n".join(block["text"] for unit in result["units"] for block in unit["blocks"])
    assert "[REDACTED:EMAIL]" in sanitized
    assert "analyst@example.com" not in sanitized


def test_unsupported_file_rejected_before_processing():
    with pytest.raises(adapter.UploadValidationError, match="Unsupported file format"):
        adapter.process_uploaded_document("notes.txt", b"not supported")


def test_empty_document_is_reported_without_calling_backend(monkeypatch):
    def should_not_run(**kwargs):
        raise AssertionError("backend should not run for empty bytes")

    monkeypatch.setattr(adapter, "extract_all_documents", should_not_run)
    result = adapter.process_uploaded_document("empty.pdf", b"")
    assert result["gate_status"] == "review_required"
    assert result["safe_to_process"] is False
    assert "empty" in result["message"].lower()


def test_oversized_file_is_rejected():
    with pytest.raises(adapter.UploadValidationError, match="25 MiB"):
        adapter.process_uploaded_document("large.pdf", b"x" * 10, max_upload_bytes=5)


def test_corrupted_pdf_is_handled_and_not_approved():
    result = adapter.process_uploaded_document("corrupt.pdf", b"not a valid PDF document")
    assert result["safe_to_process"] is False
    assert result["gate_status"] in {"review_required", "processing_failed"}
    assert result["extraction"]["complete"] is False
    assert result["extraction"]["errors"]


def test_extraction_failure_is_not_approved(monkeypatch):
    monkeypatch.setattr(adapter, "extract_all_documents", lambda **kwargs: {
        "total_blocks": 0, "blocks": [], "reports": [], "retention": None,
        "retention_status": "not_measured_no_reference_text",
        "errors": [{"block_id": "document.pdf", "error": "Document extraction failed: RuntimeError"}],
        "complete": False,
    })
    result = adapter.process_uploaded_document("broken.pdf", b"%PDF-test")
    assert result["safe_to_process"] is False
    assert result["gate_status"] == "review_required"
    assert result["extraction"]["errors"]


def test_safe_to_process_false_blocks_even_when_validation_says_passed(monkeypatch):
    monkeypatch.setattr(adapter, "extract_all_documents", lambda **kwargs: {
        "total_blocks": 1,
        "blocks": [{"id": "b1", "text": "hello there", "char_count": 11, "page_slide": 1}],
        "reports": [{"file": "document.docx", "blocks": 1, "type": "DOCX", "status": "extracted"}],
        "retention": None, "retention_status": "not_measured_no_reference_text", "errors": [], "complete": True,
    })
    monkeypatch.setattr(adapter, "process_extraction_result", lambda *args, **kwargs: {
        "status": "redacted", "units": [], "audit_events": [], "safe_to_process": False,
        "validation": {"passed": True, "checks": [], "issues": []},
    })
    result = adapter.process_uploaded_document("sample.docx", b"synthetic-docx-bytes")
    assert result["gate_status"] == "blocked"
    assert result["safe_to_process"] is False


def test_missing_or_malformed_validation_defaults_to_review(monkeypatch):
    monkeypatch.setattr(adapter, "extract_all_documents", lambda **kwargs: {
        "total_blocks": 1,
        "blocks": [{"id": "b1", "text": "hello there", "char_count": 11, "page_slide": 1}],
        "reports": [], "retention": None, "retention_status": "not_measured_no_reference_text", "errors": [], "complete": True,
    })
    monkeypatch.setattr(adapter, "process_extraction_result", lambda *args, **kwargs: {
        "status": "redacted", "units": [], "audit_events": [], "safe_to_process": True,
        "validation": {"passed": "yes", "checks": [], "issues": []},
    })
    result = adapter.process_uploaded_document("sample.docx", b"synthetic-docx-bytes")
    assert result["gate_status"] == "review_required"
    assert result["safe_to_process"] is False


def test_failed_validation_blocks_download_eligibility(monkeypatch):
    monkeypatch.setattr(adapter, "extract_all_documents", lambda **kwargs: {
        "total_blocks": 1,
        "blocks": [{"id": "b1", "text": "hello there", "char_count": 11, "page_slide": 1}],
        "reports": [], "retention": None, "retention_status": "not_measured_no_reference_text", "errors": [], "complete": True,
    })
    monkeypatch.setattr(adapter, "process_extraction_result", lambda *args, **kwargs: {
        "status": "failed", "units": [], "audit_events": [], "safe_to_process": False,
        "validation": {"passed": False, "checks": [{"name": "residual", "passed": False}], "issues": [{"code": "RESIDUAL", "message": "Residual finding"}]},
    })
    result = adapter.process_uploaded_document("sample.docx", b"synthetic-docx-bytes")
    assert result["gate_status"] == "blocked"
    assert result["safe_to_process"] is False


def test_temporary_file_is_cleaned_after_success(monkeypatch):
    observed = {}

    def fake_extract(**kwargs):
        path = Path(kwargs["docs_path"])
        files = list(path.iterdir())
        observed["path"] = path
        observed["files"] = files
        assert len(files) == 1 and files[0].is_file()
        return {
            "total_blocks": 1,
            "blocks": [{"id": "b1", "text": "hello there", "char_count": 11, "page_slide": 1}],
            "reports": [], "retention": None, "retention_status": "not_measured_no_reference_text", "errors": [], "complete": True,
        }

    monkeypatch.setattr(adapter, "extract_all_documents", fake_extract)
    monkeypatch.setattr(adapter, "process_extraction_result", lambda *args, **kwargs: {
        "status": "redacted", "units": [], "audit_events": [], "safe_to_process": True,
        "validation": {"passed": True, "checks": [], "issues": []},
    })
    adapter.process_uploaded_document("sample.docx", b"synthetic-docx-bytes")
    assert not observed["path"].exists()
    assert not observed["files"][0].exists()


def test_temporary_file_is_cleaned_after_backend_exception(monkeypatch):
    observed = {}

    def fail_extract(**kwargs):
        path = Path(kwargs["docs_path"])
        observed["path"] = path
        assert any(path.iterdir())
        raise RuntimeError("synthetic failure")

    monkeypatch.setattr(adapter, "extract_all_documents", fail_extract)
    result = adapter.process_uploaded_document("sample.pdf", b"%PDF-test")
    assert result["gate_status"] == "processing_failed"
    assert not result["safe_to_process"]
    assert not observed["path"].exists()


def test_audit_does_not_expose_original_matched_pii():
    original = "private.person@example.com"
    payload = make_docx(f"Reach private contact at {original}.")
    result = adapter.process_uploaded_document("private.docx", payload)
    audit_text = repr(result["audit_events"])
    assert original not in audit_text
    assert all("value" not in event and "matched_text" not in event for event in result["audit_events"])


def test_history_summary_excludes_document_text_and_original_units():
    result = {
        "document_id": "doc-123", "filename": "x.docx", "processed_at": "2026-10-11T10:00:00+05:30",
        "gate_status": "validated", "pii_count": 1, "redaction_count": 1,
        "extraction": {"complete": True}, "units": [{"blocks": [{"text": "sensitive raw text"}]}],
    }
    summary = adapter.history_summary(result)
    assert "sensitive raw text" not in repr(summary)
    assert "units" not in summary
    assert "text" not in summary


def test_retention_is_not_fabricated():
    result = adapter.process_uploaded_document("sample.docx", make_docx("Nothing sensitive here."))
    assert result["extraction"]["retention"] is None
    assert "not_measured" in result["extraction"]["retention_status"]

