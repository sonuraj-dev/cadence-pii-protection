# Cadence PII Protection — Frontend

A local Streamlit dashboard for the bundled Cadence PDF/DOCX/PPTX extraction and PII-redaction backend. This is a case-study prototype, not a certified production security control.

## What is included

- `app.py` — dashboard, upload flow, result review, safety status, history, and sanitized text download.
- `frontend_adapter.py` — isolated adapter that calls the current backend contract (`extract_all_documents` and `process_extraction_result`). It does not reimplement detection, redaction, or residual validation.
- `tests/test_frontend_adapter.py` — synthetic tests for backend integration, fail-closed decisions, cleanup, audit privacy, and session-history minimization.

## Install and run

Python 3.12 is recommended by the backend README. From the repository root:

```bash
python -m venv .venv
# Windows PowerShell:
.venv\Scripts\Activate.ps1
# macOS/Linux:
# source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
streamlit run app.py
```

Open the local URL printed by Streamlit. Core processing is local and does not require API keys or paid services. Scanned-PDF OCR requires Tesseract OCR to be installed and available on the local machine; OCR failure remains a review condition.

## Tests

```bash
python -m pytest -q
```

The repository's original backend tests should be run with the frontend tests. The frontend uses synthetic documents; do not put real customer or financial documents in automated tests.

## Workflow and safety gate

1. Select one or more PDF, DOCX, or PPTX documents (25 MiB maximum per file).
2. Each upload is written to a generated filename in a temporary directory.
3. The existing extraction engine runs, then its full result is passed to `process_extraction_result(...)`.
4. The existing integration pipeline handles detector calls, redaction, and residual validation.
5. The UI displays a normalized summary, sanitized text returned by the backend, privacy-safe audit events, and validation checks.
6. The temporary directory is removed on success or exception.

A document is marked **Validated** only if all of the following are explicit: extraction `complete is True`, there are no extraction errors (including block-level errors), backend `validation.passed is True`, and backend `safe_to_process is True`. Missing, malformed, or conflicting fields default to **Review required** or **Blocked**. The UI does not infer safety from redaction counts.

## Privacy behavior

- Original files are kept in a temporary directory only during synchronous processing and are removed by the temporary-directory context manager.
- The adapter does not return original extracted block text. It returns block metadata and backend-produced post-redaction text only.
- The app's recent-history table contains filenames, times, counts, extraction status, and decision only; it does not contain text or raw matched values.
- Audit output is allow-listed and excludes matched/original text values.
- Sanitized text download is enabled only when the fail-closed safety gate passes. Download content is **text-only**; original PDF/DOCX/PPTX structure and layout are not reconstructed.
- While the app is open, Streamlit's upload widget and session state hold temporary in-memory values as required for interaction. Use the “Clear session results” control before ending a shared demo session.

## Backend contract and limitations

- Confirmed existing entry points: `src.extraction.extraction_engine.extract_all_documents(docs_path=...)` and `src.integration.pipeline.process_extraction_result(extraction_result, *, document_id, source_file, file_type)`.
- Backend audit events expose type, offsets, confidence, method, replacement, document/block identifiers, and action; the frontend allow-lists these fields.
- Extracted text retention is **Not measured** when the backend returns no reference comparison. The frontend does not claim 100% retention or detection accuracy.
- The detector uses rule-based patterns and conservative name recognition. Passing the configured residual validator is not proof that every form of PII has been found or removed.
- Progress is synchronous. The UI intentionally does not fabricate live stage progress or latency metrics.
- The backend currently has no frontend framework or REST API in the provided ZIP, so this app calls the Python modules directly. The archive contained no `.git` metadata; a branch based on the latest remote `main` cannot be verified or created from this source archive alone.

## Known limitations

- Sanitized output is a text export, not a reconstructed PDF/DOCX/PPTX.
- Scanned PDF OCR depends on local Tesseract installation and image quality.
- Upload limit is enforced at 25 MiB per document by the adapter/UI.
- No data is persisted across app sessions and no server-side multi-user authentication is included.
- This prototype has no downstream dispatch action; it only reports whether backend results satisfy the safety gate.
